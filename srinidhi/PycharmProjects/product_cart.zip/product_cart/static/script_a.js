var app = angular.module('cart', []);

app.controller("ctrl", function($scope, $http){

    $scope.product = $http.get("select_a.html");
    
    $scope.view = $http.get("display_a.html");

});








app.config(function($interpolateProvider) {
    $interpolateProvider.startSymbol('[[');
    $interpolateProvider.endSymbol(']]');
});

